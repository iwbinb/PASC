#!/bin/bash
while true
do
    ./rhminer -s pasc.f2pool.com:15555 -su 86646-64.575590eb02e9474d.01 -cpu -cputhreads 4 -r 40
    sleep 5s
done




